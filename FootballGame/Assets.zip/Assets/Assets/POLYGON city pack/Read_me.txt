Thank you for buying this POLYGON city package, if you like it, rate our asset in the store to support my work.

Performance :

If you`re do with the city, i suggest, to use occculus culling, that really save performance and turn the not seen object off, like if something is behind a wall.

For the collider do i suggest to programm something, where you detect with cordinates, which are needed and which not.


The thumbnail of the prefabs isn`t loading ?

Select the prefabs, then clikc o nthe right mouse button and then -> reimport.





Placing of the Floor :

If you placed the first floor part, then smooth the cordinates, like : 12.123453 = 12, that will avoid buggy building with the alt key, to move the floor part in metre steps.



All objects which you place to cover the floor are in metres simply place on floor in the scene -> copy the position and place the second part you need and past the position in, if you have the needed
floors in the scene, press " strg " and move the floor parts, you will see that it moves in 1 m steps.


placing of fence and walls :

the fences are also in metre steps, but the wall is only 0.4m wide and if you see, you need about half metre to get ti right, use the value 0.4 instead of the default 1 m.

Day and night and lights.

For changing the City time, you can use the day or night skybox.
For the windows can you easy drag the light materials on and for the lamps too.
to turn the light on, set the light object in the lamp on active after lightbakje the scene.




For ask, ask on the support site and i wish you much success with you project.